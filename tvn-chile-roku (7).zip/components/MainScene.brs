sub init()
    m.channelList = m.top.findNode("channelList")
    m.videoPlayer = m.top.findNode("videoPlayer")
    m.hintLabel = m.top.findNode("hintLabel")
    m.titleLabel = m.top.findNode("titleLabel")
    m.categoryLabel = m.top.findNode("categoryLabel")
    m.catArrowLeft = m.top.findNode("catArrowLeft")
    m.catArrowRight = m.top.findNode("catArrowRight")
    m.statusLabel = m.top.findNode("statusLabel")

    ' URL del archivo de canales (editable sin tocar el código de la app)
    m.playlistUrl = "https://herramientas-panel.vercel.app/tv.m3u"

    m.allChannels = []       ' todos los canales, sin filtrar
    m.categories = []        ' lista de nombres de categoría, "Favoritos" y "Todos" primero
    m.categoryIndex = 0
    m.currentChannels = []   ' canales de la categoría actual (los que se listan)
    m.currentIndex = 0
    m.favorites = {}         ' mapa url -> true
    m.toastLabel = invalid
    m.toastTimer = invalid
    m.favToastLabel = invalid
    m.favToastTimer = invalid
    m.rewindHeld = false
    m.fastforwardHeld = false
    m.favHeld = false

    loadFavorites()

    m.channelList.ObserveField("itemSelected", "onChannelSelected")
    m.channelList.ObserveField("itemFocused", "onChannelFocused")
    m.videoPlayer.ObserveField("state", "onVideoStateChange")

    ' Apaga la barra/overlay nativa de Roku para que no compita con nada propio
    m.videoPlayer.EnableTrickPlay = false

    loadPlaylist()
end sub

' ---------- Favoritos (persistidos en el registro del dispositivo) ----------

sub defaultFavoriteUrls() as object
    return [
        "https://unlimited1-cl-isp.dps.live/mega/mega.smil/playlist.m3u8"          ' Mega en vivo
        "https://stream-gtlc.telecentro.net.ar/hls/canal26hls/main.m3u8"           ' Canal 26
        "https://5f700d5b2c46f.streamlock.net/canal22/canal22/playlist.m3u8"       ' Canal 22
        "http://coninfo.net:1935/9linklivert/smil:9linkmultibr.smil/playlist.m3u8" ' Canal 9 Resistencia
        "https://stream.arcast.live/ahora/ahora/playlist.m3u8"                     ' Canal 9 Litoral
        "http://arcast.net:1935/mp/mp/playlist.m3u8"                               ' Canal 13 La Rioja
        "http://45.228.235.116:8000/play/a0iy/index.m3u8"                         ' AXN
        "https://mblesmain01.telesur.ultrabase.net/mbliveMain/hd/playlist.m3u8"    ' Telesur en vivo
        "https://redirector.rudo.video/hls-video/c54ac2799874375c81c1672abb700870537c5223/bravo/bravo.smil/playlist.m3u8?did=b2201035844768f58630b7eef" ' Bravo TV
        "https://amg26268-amg26268c14-freelivesports-emea-10267.playouts.now.amagi.tv/ts-us-e2-n2/playlist/amg26268-sportsstudio-tycsports-freelivesportsemea/playlist.m3u8" ' TyC Sports
        "https://videostream.shockmedia.com.ar:19360/neotvdigital/neotvdigital.m3u8" ' Neo TV
        "https://unlimited1-us.dps.live/nettv/nettv.smil/playlist.m3u8"            ' NET TV
    ]
end function

sub loadFavorites()
    section = CreateObject("roRegistrySection", "favorites")
    m.favoriteOrder = []
    m.favorites = {}

    if section.Exists("urls")
        stored = section.Read("urls")
        if stored <> invalid and Len(stored) > 0
            for each u in stored.Split("|")
                if Len(u) > 0
                    m.favoriteOrder.Push(u)
                    m.favorites[u] = true
                end if
            end for
        end if
    end if

    ' Si por cualquier motivo (primera vez, o se resetearon con una
    ' actualización) no hay ningún favorito guardado, arrancamos con
    ' un set por defecto en vez de dejar la pantalla vacía.
    if m.favoriteOrder.count() = 0
        for each u in defaultFavoriteUrls()
            m.favoriteOrder.Push(u)
            m.favorites[u] = true
        end for
        saveFavorites()
    end if
end sub

sub saveFavorites()
    section = CreateObject("roRegistrySection", "favorites")
    section.Write("urls", m.favoriteOrder.Join("|"))
    section.Flush()
end sub

sub moveFavorite(direction as integer)
    if m.categories.count() = 0 then return
    if m.categories[m.categoryIndex] <> "Favoritos" then return
    if m.favoriteOrder.count() < 2 then return
    if m.currentIndex < 0 or m.currentIndex >= m.favoriteOrder.count() then return

    otherIdx = m.currentIndex + direction
    if otherIdx < 0 or otherIdx >= m.favoriteOrder.count() then return

    tmp = m.favoriteOrder[m.currentIndex]
    m.favoriteOrder[m.currentIndex] = m.favoriteOrder[otherIdx]
    m.favoriteOrder[otherIdx] = tmp

    saveFavorites()
    m.currentIndex = otherIdx
    renderCategory(false)
end sub

sub showInfoToast(ch as object)
    dt = CreateObject("roDateTime")
    dt.ToLocalTime()
    hh = dt.GetHours()
    mm = dt.GetMinutes()
    hhStr = hh.ToStr()
    if hh < 10 then hhStr = "0" + hhStr
    mmStr = mm.ToStr()
    if mm < 10 then mmStr = "0" + mmStr
    timeStr = hhStr + ":" + mmStr

    showFavoriteToast(timeStr + "  •  " + ch.name, "0xFFFFFFFF")
end sub

sub showFavoriteToast(text as string, color = "0x66FF66FF" as string)
    if m.favToastLabel <> invalid
        m.top.RemoveChild(m.favToastLabel)
        m.favToastLabel = invalid
    end if
    if m.favToastTimer <> invalid
        m.favToastTimer.control = "stop"
        m.top.RemoveChild(m.favToastTimer)
        m.favToastTimer = invalid
    end if

    label = CreateObject("roSGNode", "Label")
    label.text = text
    label.translation = [66, 150]
    label.font = "font:MediumBoldSystemFont"
    label.color = color
    m.top.AppendChild(label)
    m.favToastLabel = label

    timer = CreateObject("roSGNode", "Timer")
    timer.duration = 2
    timer.ObserveField("fire", "onFavToastTimerFire")
    m.top.AppendChild(timer)
    m.favToastTimer = timer
    timer.control = "start"
end sub

sub onFavToastTimerFire()
    if m.favToastLabel <> invalid
        m.top.RemoveChild(m.favToastLabel)
        m.favToastLabel = invalid
    end if
    if m.favToastTimer <> invalid
        m.top.RemoveChild(m.favToastTimer)
        m.favToastTimer = invalid
    end if
end sub

sub toggleFavorite(ch as object)
    if ch = invalid then return
    if m.favorites.DoesExist(ch.url)
        m.favorites.Delete(ch.url)
        newOrder = []
        for each u in m.favoriteOrder
            if u <> ch.url then newOrder.Push(u)
        end for
        m.favoriteOrder = newOrder
        showFavoriteToast("Quitado de Favoritos: " + ch.name, "0xFF9900FF")
    else
        m.favorites[ch.url] = true
        m.favoriteOrder.Push(ch.url)
        showFavoriteToast("★ Agregado a Favoritos: " + ch.name, "0x33CC33FF")
    end if
    saveFavorites()
    ' Si estamos parados en Favoritos, refrescamos porque puede cambiar el conteo
    if m.categories.count() > 0 and m.categories[m.categoryIndex] = "Favoritos"
        renderCategory(true)
    else
        renderCategory(false)
    end if
end sub

' ---------- Carga de la playlist ----------

sub loadPlaylist()
    m.statusLabel.text = "Cargando lista de canales..."
    m.statusLabel.visible = true
    m.channelList.visible = false
    m.categoryLabel.visible = false
    m.catArrowLeft.visible = false
    m.catArrowRight.visible = false

    m.loaderTask = CreateObject("roSGNode", "LoaderTask")
    m.loaderTask.ObserveField("channelsJson", "onChannelsLoaded")
    m.loaderTask.ObserveField("errorMessage", "onLoadError")
    m.loaderTask.uri = m.playlistUrl
    m.loaderTask.control = "RUN"
end sub

sub onChannelsLoaded(event as object)
    json = event.GetData()
    if json = invalid or Len(json) = 0 then return

    parsed = ParseJson(json)
    if parsed = invalid or parsed.count() = 0
        m.statusLabel.text = "La lista de canales está vacía o no se pudo leer."
        return
    end if

    m.allChannels = parsed

    ' Armamos la lista de categorías: "Favoritos" y "Todos" primero, después
    ' las que aparezcan en los canales, en el orden en que se encuentran.
    cats = ["Favoritos", "Todos"]
    for each ch in m.allChannels
        cat = ch.category
        if cat = invalid or Len(cat) = 0 then cat = "Otros"
        found = false
        for each c in cats
            if c = cat then found = true
        end for
        if not found then cats.Push(cat)
    end for
    m.categories = cats
    m.categoryIndex = 0 ' arrancamos en Favoritos

    m.statusLabel.visible = false
    m.categoryLabel.visible = true
    m.catArrowLeft.visible = true
    m.catArrowRight.visible = true
    m.channelList.visible = true

    renderCategory(true)
    m.channelList.setFocus(true)
end sub

sub onLoadError(event as object)
    msg = event.GetData()
    if msg = invalid or Len(msg) = 0 then return
    m.statusLabel.text = msg
    m.statusLabel.visible = true
end sub

' ---------- Render de categoría / lista ----------

sub renderCategory(resetSelection as boolean)
    if m.categories.count() = 0 then return
    catName = m.categories[m.categoryIndex]

    if catName = "Favoritos"
        list = []
        for each url in m.favoriteOrder
            for each ch in m.allChannels
                if ch.url = url
                    list.Push(ch)
                    exit for
                end if
            end for
        end for
        m.currentChannels = list
    else if catName = "Todos"
        m.currentChannels = m.allChannels
    else
        list = []
        for each ch in m.allChannels
            c = ch.category
            if c = invalid or Len(c) = 0 then c = "Otros"
            if c = catName then list.Push(ch)
        end for
        m.currentChannels = list
    end if

    countTxt = m.currentChannels.count().ToStr()
    idxTxt = (m.categoryIndex + 1).ToStr()
    totalTxt = m.categories.count().ToStr()
    m.categoryLabel.text = catName + "  (" + countTxt + ")   [" + idxTxt + "/" + totalTxt + "]"

    content = CreateObject("roSGNode", "ContentNode")
    i = 0
    for each ch in m.currentChannels
        item = content.CreateChild("ContentNode")
        i = i + 1
        item.title = buildItemTitle(i - 1, ch)
    end for
    m.channelList.content = content

    if resetSelection
        m.currentIndex = 0
    else
        if m.currentIndex >= m.currentChannels.count()
            m.currentIndex = 0
        end if
    end if

    if m.currentChannels.count() > 0
        m.channelList.jumpToItem = m.currentIndex
    end if

    updateNeighborArrows()
end sub

function buildItemTitle(idx as integer, ch as object) as string
    star = ""
    if m.favorites.DoesExist(ch.url) then star = "★ "
    num = (idx + 1).ToStr()
    if idx + 1 < 10 then num = "0" + num
    return num + ". " + star + ch.name
end function

' Marca con "^" el canal justo arriba del foco actual y con "v" el de abajo
' (caracteres simples que sí se ven bien en la fuente del Roku), para que
' sea obvio hacia dónde mover el control sin tener que leer nada.
sub updateNeighborArrows()
    content = m.channelList.content
    if content = invalid then return
    n = content.GetChildCount()
    for idx = 0 to n - 1
        ch = m.currentChannels[idx]
        base = buildItemTitle(idx, ch)
        if idx = m.currentIndex - 1
            base = "^  " + base
        else if idx = m.currentIndex + 1
            base = "v  " + base
        end if
        content.GetChild(idx).title = base
    end for
end sub

' ---------- Aviso temporal de categoría (nodo nuevo cada vez, no se recicla) ----------

sub showCategoryToast(text as string)
    if m.toastLabel <> invalid
        m.top.RemoveChild(m.toastLabel)
        m.toastLabel = invalid
    end if
    if m.toastTimer <> invalid
        m.toastTimer.control = "stop"
        m.top.RemoveChild(m.toastTimer)
        m.toastTimer = invalid
    end if

    label = CreateObject("roSGNode", "Label")
    label.text = "CAT. " + text
    label.translation = [66, 110]
    label.font = "font:LargeBoldSystemFont"
    label.color = "0xFFCC00FF"
    m.top.AppendChild(label)
    m.toastLabel = label

    timer = CreateObject("roSGNode", "Timer")
    timer.duration = 2
    timer.ObserveField("fire", "onToastTimerFire")
    m.top.AppendChild(timer)
    m.toastTimer = timer
    timer.control = "start"
end sub

sub onToastTimerFire()
    if m.toastLabel <> invalid
        m.top.RemoveChild(m.toastLabel)
        m.toastLabel = invalid
    end if
    if m.toastTimer <> invalid
        m.top.RemoveChild(m.toastTimer)
        m.toastTimer = invalid
    end if
end sub

sub changeCategory(direction as integer)
    if m.categories.count() = 0 then return
    m.categoryIndex = (m.categoryIndex + direction + m.categories.count()) mod m.categories.count()
    renderCategory(true)
end sub

sub onChannelFocused()
    m.currentIndex = m.channelList.itemFocused
    updateNeighborArrows()
end sub

' ---------- Reproducción ----------

sub onChannelSelected()
    m.currentIndex = m.channelList.itemSelected
    playChannel(m.currentIndex)
end sub

sub playChannel(idx as integer)
    if idx < 0 or idx >= m.currentChannels.count() then return
    m.currentIndex = idx
    ch = m.currentChannels[idx]

    videoContent = CreateObject("roSGNode", "ContentNode")
    videoContent.url = ch.url
    videoContent.streamFormat = "hls"
    videoContent.title = ch.name
    videoContent.live = true

    if ch.DoesExist("userAgent")
        headers = CreateObject("roAssociativeArray")
        headers["User-Agent"] = ch.userAgent
        videoContent.AddFields({ HttpHeaders: headers })
    end if

    m.videoPlayer.content = videoContent
    m.videoPlayer.visible = true
    m.videoPlayer.control = "play"
    m.videoPlayer.setFocus(true)

    m.channelList.visible = false
    m.titleLabel.visible = false
    m.categoryLabel.visible = false
    m.catArrowLeft.visible = false
    m.catArrowRight.visible = false
    m.hintLabel.visible = false
end sub

sub nextChannel()
    if m.currentChannels.count() = 0 then return
    idx = (m.currentIndex + 1) mod m.currentChannels.count()
    playChannel(idx)
end sub

sub prevChannel()
    if m.currentChannels.count() = 0 then return
    idx = m.currentIndex - 1
    if idx < 0 then idx = m.currentChannels.count() - 1
    playChannel(idx)
end sub

sub onVideoStateChange()
    state = m.videoPlayer.state
    if state = "error"
        showList()
    end if
end sub

sub showList()
    m.videoPlayer.control = "stop"
    m.videoPlayer.visible = false
    m.channelList.visible = true
    m.titleLabel.visible = true
    m.categoryLabel.visible = true
    m.catArrowLeft.visible = true
    m.catArrowRight.visible = true
    m.hintLabel.visible = true
    renderCategory(false)
    m.channelList.setFocus(true)
end sub

' ---------- Control remoto ----------

function onKeyEvent(key as string, press as boolean) as boolean
    if not press
        if key = "rewind" then m.rewindHeld = false
        if key = "fastforward" then m.fastforwardHeld = false
        if key = "options" or key = "replay" then m.favHeld = false
        return false
    end if

    if key = "back"
        if m.videoPlayer.visible
            showList()
            return true
        end if
        return false
    end if

    if m.videoPlayer.visible
        if key = "down"
            nextChannel()
            return true
        else if key = "up"
            prevChannel()
            return true
        else if key = "right"
            changeCategory(1)
            if m.currentChannels.count() > 0 then playChannel(0)
            showCategoryToast(m.categories[m.categoryIndex])
            return true
        else if key = "left"
            changeCategory(-1)
            if m.currentChannels.count() > 0 then playChannel(0)
            showCategoryToast(m.categories[m.categoryIndex])
            return true
        else if key = "options" or key = "replay"
            if not m.favHeld
                m.favHeld = true
                if m.currentIndex >= 0 and m.currentIndex < m.currentChannels.count()
                    toggleFavorite(m.currentChannels[m.currentIndex])
                end if
            end if
            return true
        else if key = "OK"
            if m.currentIndex >= 0 and m.currentIndex < m.currentChannels.count()
                showInfoToast(m.currentChannels[m.currentIndex])
            end if
            return true
        end if
    else
        if key = "right"
            changeCategory(1)
            return true
        else if key = "left"
            changeCategory(-1)
            return true
        else if key = "options" or key = "replay"
            if not m.favHeld
                m.favHeld = true
                if m.currentIndex >= 0 and m.currentIndex < m.currentChannels.count()
                    toggleFavorite(m.currentChannels[m.currentIndex])
                end if
            end if
            return true
        else if key = "rewind"
            if not m.rewindHeld
                m.rewindHeld = true
                moveFavorite(-1)
            end if
            return true
        else if key = "fastforward"
            if not m.fastforwardHeld
                m.fastforwardHeld = true
                moveFavorite(1)
            end if
            return true
        end if
    end if

    return false
end function
