sub init()
    m.top.functionName = "doFetch"
end sub

sub doFetch()
    request = CreateObject("roUrlTransfer")
    request.SetUrl(m.top.uri)
    request.SetCertificatesFile("common:/certs/ca-bundle.crt")
    request.InitClientCertificates()
    request.EnableEncodings(true)

    body = request.GetToString()

    if body = invalid or Len(body) = 0
        m.top.errorMessage = "No se pudo descargar la lista de canales. Verificá tu conexión."
        return
    end if

    channels = parseM3U(body)

    if channels.count() = 0
        m.top.errorMessage = "La lista de canales está vacía o no se pudo leer."
        return
    end if

    m.top.channelsJson = FormatJson(channels)
end sub

function parseM3U(text as string) as object
    result = []
    text = text.Replace(Chr(13), "")
    lines = text.Split(Chr(10))

    currentName = invalid
    currentUA = invalid
    currentCategory = invalid

    for each rawLine in lines
        line = rawLine.Trim()
        if Left(line, 8) = "#EXTINF:"
            commaPos = Instr(1, line, ",")
            if commaPos > 0
                currentName = Mid(line, commaPos + 1).Trim()
            else
                currentName = "Canal"
            end if
            currentUA = invalid
            currentCategory = "Otros"
            gtStart = Instr(1, line, "group-title=" + Chr(34))
            if gtStart > 0
                gtValStart = gtStart + 13
                gtEnd = Instr(gtValStart, line, Chr(34))
                if gtEnd > gtValStart
                    currentCategory = Mid(line, gtValStart, gtEnd - gtValStart)
                end if
            end if
        else if Left(line, 27) = "#EXTVLCOPT:http-user-agent="
            currentUA = Mid(line, 28).Trim()
        else if Len(line) > 0 and Left(line, 1) <> "#"
            if currentName <> invalid
                ch = {
                    name: currentName
                    url: line
                    category: currentCategory
                }
                if currentUA <> invalid
                    ch.userAgent = currentUA
                end if
                result.Push(ch)
                currentName = invalid
                currentUA = invalid
                currentCategory = invalid
            end if
        end if
    end for

    return result
end function
